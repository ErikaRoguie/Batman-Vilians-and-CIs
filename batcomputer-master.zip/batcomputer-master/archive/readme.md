# ARCHIVE
### ⚠ WARNING ⚠ Everything in this section is no longer used

Files here were no longer needed when the project switched from DataBricks to Azure ML for training. 

Is kept around as useful resource and a functional reference for driving DataBricks with Azure DevOps Pipelines

## Folders
- `databricks` - JSON files for setting up cluster and jobs in DataBricks
- `pipelines` - Azure DevOps pipelines
- `notebooks` - Python notebooks that carry out the training
- `scripts` - Stuff
