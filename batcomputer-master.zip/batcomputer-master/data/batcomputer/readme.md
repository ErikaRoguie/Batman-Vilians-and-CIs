Put **crime.zip** here!

Download from [https://bcmisc.blob.core.windows.net/shared/crime.zip](https://bcmisc.blob.core.windows.net/shared/crime.zip)