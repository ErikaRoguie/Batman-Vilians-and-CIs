var API_ENDPOINT = "" // "http://localhost:7071/api" //"http://localhost:8000/api" 
var API_CODE = "phf0AqooWf5495qHqGZ4Gx5KKfz2/hJ1XKM89rv6/wFEBLJDl3yKqQ=="