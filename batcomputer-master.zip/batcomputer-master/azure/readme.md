# Azure Scripts / Templates

#### [ARM Template - Deploy to ACI](./aci-arm-template)

#### [Deploy Azure ML Workspace Script](./aml-script)